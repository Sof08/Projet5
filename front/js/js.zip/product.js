//recuration de l'url de la page du produit
const str = window.location.search;
console.log(str);
//chercher les parametres dans Url
const urlParams = new URLSearchParams(str);
//recuperer l'ID dans les parametres
const id_product = urlParams.get('id');

//console.log(id_product);
const url_product_api = `http://localhost:3000/api/products/${id_product}`;

fetch(url_product_api)
    .then((res) => res.json())
    .then((product) => {
        //image
        const imageElement = document.createElement("img");
        imageElement.src = product.imageUrl;
        document.querySelector('.item__img').appendChild(imageElement);

        //nom produit
        const nomElement = document.createElement("name");
        //product.name concerne l'api
        nomElement.innerText = product.name;
        document.querySelector('.item__content__titlePrice').appendChild(nomElement);

        //prix du produit
        document.querySelector('#price').textContent = product.price;
        //description du produit
        //querySelector concerne l'id dans html, textContent ou innertext concerne l'api
        document.querySelector('#description').textContent = product.description;
        
        //liste des couleurs recuperation des couleurs dans l'api
        const couleurs = product.colors;
        //faire une boucle sur le tableau couleur vu dans l'api, pour parcourir et selectionner les couleurs une à une
        for (const couleur of couleurs) {
            //creation de l'element "option"
            /*<select name="" id="colors">
                <option value="valeur=couleur">text=couleur</option>
            </select>*/
            couleurOption = document.createElement("option");
            //definir le nom de l'option
            couleurOption.text = couleur;
            //definir la valeur de l'option
            couleurOption.value = couleur;
            //rattacher l'element option à l'élément select qui a ID = colors
            document.querySelector('#colors').appendChild(couleurOption);
        }
        

    });




